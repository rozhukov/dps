# json-metadata
The Metadata schema and examples for JSON encoding
