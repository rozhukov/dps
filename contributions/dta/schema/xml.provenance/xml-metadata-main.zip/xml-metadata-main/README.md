# xml-metadata
Metadata schema and examples for XML encoding
